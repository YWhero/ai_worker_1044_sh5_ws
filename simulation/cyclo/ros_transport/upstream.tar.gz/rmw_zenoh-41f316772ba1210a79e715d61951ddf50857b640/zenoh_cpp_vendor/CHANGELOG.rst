^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package zenoh_cpp_vendor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.2.10 (2026-07-22)
-------------------
* Bump zenoh to 1.8.0 - 2nd attempt (`#966 <https://github.com/ros2/rmw_zenoh/issues/966>`_)
* Revert 1.8.0 (`#962 <https://github.com/ros2/rmw_zenoh/issues/962>`_)
* Build against rust >= 1.75 for ROS Lyrical (`#949 <https://github.com/ros2/rmw_zenoh/issues/949>`_)
* Bump zenoh to 1.8.0 (`#940 <https://github.com/ros2/rmw_zenoh/issues/940>`_)
* Allow use of non-vendored Zenoh if present (`#910 <https://github.com/ros2/rmw_zenoh/issues/910>`_)
* Bump zenoh to 1.7.1 (`#873 <https://github.com/ros2/rmw_zenoh/issues/873>`_)
* Contributors: Yuyuan Yuan, Julien Enoch, Shane Loretz, Denis Biryukov, Øystein Sture, mergify[bot]

0.2.9 (2025-11-12)
------------------
* Bump zenoh to 1.6.2 (`#850 <https://github.com/ros2/rmw_zenoh/issues/850>`_)
* Contributors: Julien Enoch

0.2.8 (2025-10-05)
------------------

0.2.7 (2025-09-10)
------------------
* Bump Zenoh to 1.5.1 (`#777 <https://github.com/ros2/rmw_zenoh/issues/777>`_)
* Contributors: Julien Enoch

0.2.6 (2025-08-21)
------------------
* Bump Zenoh to v1.5.0 (`#736 <https://github.com/ros2/rmw_zenoh/issues/736>`_)
* Change zenoh-c features to use its default + shared-memory + transport_serial (`#716 <https://github.com/ros2/rmw_zenoh/issues/716>`_)
* Contributors: ChenYing Kuo (CY), Julien Enoch, Yadunund, Yuyuan Yuan

0.2.5 (2025-06-18)
------------------
* Bump Zenoh to 1.4.0 (`#658 <https://github.com/ros2/rmw_zenoh/issues/658>`_)
* fix: pin rust toolchain to v1.75.0 (`#635 <https://github.com/ros2/rmw_zenoh/issues/635>`_)
* fix: use the right commit to bump zenoh to v1.3.2 (`#632 <https://github.com/ros2/rmw_zenoh/issues/632>`_)
* Contributors: Julien Enoch, Yadunund, Yuyuan Yuan

0.2.4 (2025-04-20)
------------------
* Bump Zenoh to v1.3.2 and improve e2e reliability with HeartbeatSporadic (`#593 <https://github.com/ros2/rmw_zenoh/issues/593>`_)
* Contributors: Julien Enoch

0.2.3 (2025-03-20)
------------------
* Fix liveliness crash in debugg mode (`#549 <https://github.com/ros2/rmw_zenoh/issues/549>`_)
* Bump zenoh-cpp to 2a127bb, zenoh-c to 3540a3c, and zenoh to f735bf5 (`#503 <https://github.com/ros2/rmw_zenoh/issues/503>`_) (`#511 <https://github.com/ros2/rmw_zenoh/issues/511>`_)
* Enable Zenoh UDP transport (`#486 <https://github.com/ros2/rmw_zenoh/issues/486>`_) (`#488 <https://github.com/ros2/rmw_zenoh/issues/488>`_)
* Contributors: Hugal31, Luca Cominardi, Yuyuan Yuan

0.2.2 (2025-02-19)
------------------
* Bump zenoh-c to 261493 and zenoh-cpp to 5dfb68c (`#466 <https://github.com/ros2/rmw_zenoh/issues/466>`_)
* Bump Zenoh to commit id 3bbf6af (1.2.1 + few commits) (`#461 <https://github.com/ros2/rmw_zenoh/issues/461>`_)
* Contributors: Julien Enoch

0.2.1 (2025-02-04)
------------------
* Bump Zenoh to commit id e4ea6f0 (1.2.0 + few commits) (`#448 <https://github.com/ros2/rmw_zenoh/issues/448>`_)
* Bump zenoh-c and zenoh-cpp to 1.1.1 (`#431 <https://github.com/ros2/rmw_zenoh/issues/431>`_)
* Update Zenoh version (`#409 <https://github.com/ros2/rmw_zenoh/issues/409>`_)
* Contributors: ChenYing Kuo (CY), Julien Enoch, Yadunund, Yuyuan Yuan

0.2.0 (2025-01-02)
------------------
* Vendors zenoh-cpp for rmw_zenoh.
* Contributors: Alejandro Hernández Cordero, Chris Lalancette, Franco Cipollone, Julien Enoch, Yadunund, Yuyuan Yuan
